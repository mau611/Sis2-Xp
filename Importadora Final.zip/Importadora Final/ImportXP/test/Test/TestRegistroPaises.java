package Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import application.RegistroPaisesController;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Jeff
 */
public class TestRegistroPaises {
    @Test
    public void estaVacio() {
        
        RegistroPaisesController rp=new RegistroPaisesController();
        assertTrue(rp.estaVacio(""));
    }
    @Test
    public void noEstaVacio() {
        
        RegistroPaisesController rp=new RegistroPaisesController();
        assertFalse(rp.estaVacio("Ecuador"));
    }
    
    
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
