package Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static org.junit.Assert.*;
import org.junit.Test;
import Codigo.validacionesBusquedas;
/**
 *
 * @author Usuario
 */
public class TestBusquedaPedidosController {
    public TestBusquedaPedidosController(){
    }
    /**
     * Test of validarNombre method, of class validacionesBusquedas.
     */
    @Test
    public void testValidarNombre() {
        System.out.println("validarNombre");
        String texto = "Alan Arandia";
        validacionesBusquedas instance = new validacionesBusquedas();
        boolean expResult = true;
        boolean result = instance.validarNombre(texto);
        assertEquals(expResult, result);
        assertTrue(result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of validarTextoyNumeros method, of class validacionesBusquedas.
     */
    @Test
    public void testValidarTextoyNumeros() {
        System.out.println("validarTextoyNumeros");
        String texto = "PS4 y 701Z";
        validacionesBusquedas instance = new validacionesBusquedas();
        boolean expResult = true;
        boolean result = instance.validarTextoyNumeros(texto);
        assertEquals(expResult, result);
        assertTrue(result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of validarTelyCi method, of class validacionesBusquedas.
     */
    @Test
    public void testValidarTelyCi() {
        System.out.println("validarTelyCi");
        String texto = "7892633";
        validacionesBusquedas instance = new validacionesBusquedas();
        boolean expResult = true;
        boolean result = instance.validarTelyCi(texto);
        assertEquals(expResult, result);
        assertTrue(result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of fechaValida method, of class validacionesBusquedas.
     */
    @Test
    public void testFechaValida() {
        System.out.println("fechaValida");
        String fechaInicial = "2017-05-15";
        String fechaFinal = "2017-05-25";
        validacionesBusquedas instance = new validacionesBusquedas();
        boolean expResult = true;
        boolean result = instance.fechaValida(fechaInicial, fechaFinal);
        assertEquals(expResult, result);
        assertTrue(result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
}
