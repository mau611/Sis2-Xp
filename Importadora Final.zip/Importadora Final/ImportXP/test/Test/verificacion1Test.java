/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Codigo.verificacion1;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

/**
 *
 * @author Mauricio
 */
public class verificacion1Test {
    verificacion1 ver = new verificacion1();
    public verificacion1Test() {
    }
    @Test
    public void testValidarPasword() {
       String texto = "12";        
        assertFalse(ver.validarPasword(texto));
        texto = "2427a4aA";     
        assertTrue(ver.validarPasword(texto));
    }

    /**
     * Test of validarNombre method, of class verificacion1.
     */
    @Test
    public void testValidarNombre() {
        String texto = "pablo1";        
        assertFalse(ver.validarNombre(texto));
        texto = "pablo";     
        assertTrue(ver.validarNombre(texto));
    }

    /**
     * Test of validarCI method, of class verificacion1.
     */
    @Test
    public void testValidarCI() {
        String texto = "12";        
        assertFalse(ver.validarCI(texto));
        texto = "242424";     
        assertTrue(ver.validarCI(texto));
    }

    /**
     * Test of validarTelf method, of class verificacion1.
     */
    @Test
    public void testValidarTelf() {
        String texto = "12";        
        assertFalse(ver.validarTelf(texto));
        texto = "2424247";     
        assertTrue(ver.validarTelf(texto));
    }
}


