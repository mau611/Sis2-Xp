INSERT INTO pedido(
            id_pedido, id_usuario, id_cliente, id_est, id_proveedor, fecha_pedido, fecha_llegada, costo_pedido)
    VALUES (789        , 3040     ,7892652   ,3        ,4040        ,2010-05-12    ,2010-05-30   ,450);
INSERT INTO pedido(
            id_pedido, id_usuario, id_cliente, id_est, id_proveedor, fecha_pedido, fecha_llegada, costo_pedido)
    VALUES (851      ,8040        ,89528251  ,1       ,8921         ,2013-08-01    ,2013-08-15   ,1000);
INSERT INTO pedido(
            id_pedido, id_usuario, id_cliente, id_est, id_proveedor, fecha_pedido, fecha_llegada, costo_pedido)
    VALUES (985      ,2045       ,789481     ,2       ,5488       ,2012-12-05    ,2012-12-27   ,750);
INSERT INTO pedido(
            id_pedido, id_usuario, id_cliente, id_est, id_proveedor, fecha_pedido, fecha_llegada, costo_pedido)
    VALUES (188      ,7895        ,789162    ,3      ,4897        ,2015-04-30    ,2013-05-15   ,2000);
INSERT INTO pedido(
            id_pedido, id_usuario, id_cliente, id_est, id_proveedor, fecha_pedido, fecha_llegada, costo_pedido)
    VALUES (1598      ,4892       ,772182    ,2       ,1486        ,2016-02-10    ,2016-02-20   ,789);
INSERT INTO pedido(
            id_pedido, id_usuario, id_cliente, id_est, id_proveedor, fecha_pedido, fecha_llegada, costo_pedido)
    VALUES (9453      ,2187        ,48921    ,3      ,14892       ,2016-06-05    ,2013-06-25   ,8923);