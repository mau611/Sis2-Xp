/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import Codigo.verificacion1;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Mauricio
 */
public class RegistroEmpleadoController{
    @FXML TextField nombre,carnet,usuario,password;
    String user,pass,nom,ci;
    verificacion1 ver = new verificacion1();
    @FXML private void botonAtras(ActionEvent e) throws IOException{
        Main.stage.close();
        Parent root = FXMLLoader.load(getClass().getResource("OpcionesAdministrador.fxml"));
        Scene scene = new Scene(root);
        Main.stage.setTitle("");
        Main.stage.setScene(scene);
        Main.stage.show();
    }
    @FXML private void ingresar(ActionEvent e){
        ResultSet res;
        user = usuario.getText();
        pass = password.getText();
        nom = nombre.getText();
        ci = carnet.getText();
        nombre.setText("");
        carnet.setText("");
        usuario.setText("");
        password.setText("");
        boolean aceptado = ver.validarPasword(pass) && ver.validarCI(ci) && ver.validarNombre(nom);
        try{
            if(aceptado){
                res = Main.conector.consultar("select registroEmpleado('" + user +"','"+ pass +"');");
                if(res.next()){
                    String retorno = res.getString("registroEmpleado");
                    if(retorno.equals("correcto")){
                        JOptionPane.showMessageDialog(null, "REGISTRADO");
                    }else if (retorno.equals("usuarioYaExiste")){
                        JOptionPane.showMessageDialog(null, "Nombre de usuario en uso");
                    }
                }
            }else{JOptionPane.showMessageDialog(null, "No registrado, verifique los datos");}
        } catch (Exception ev) {
                System.err.println("Error : "+ev);
        }
    }
}
