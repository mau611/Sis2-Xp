/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;


/**
 *
 * @author Usuario
 */

public class SeleccionUsuarioController {

    @FXML
    private void usuarioRegistrado(ActionEvent a){
        try{
            Main.stage.close();
            Parent root = FXMLLoader.load(getClass().getResource("clienteExistente.fxml"));
            Scene scene = new Scene(root);
                    //scene.getStylesheets().add(getClass().getResource("/pkgEstilo/principal.css").toExternalForm());
	 
            Main.stage.setScene(scene);
            Main.stage.setTitle("REGISTRO PEDIDOS");
            Main.stage.show();
        }catch(Exception e){
            System.err.println(e);
        }
    }
    @FXML
    private void usuarioNoRegistrado(ActionEvent a){
        try{
            Main.stage.close();
            Parent root = FXMLLoader.load(getClass().getResource("RegistroNuevoCliente.fxml"));
            Scene scene = new Scene(root);
                    //scene.getStylesheets().add(getClass().getResource("/pkgEstilo/principal.css").toExternalForm());
	 
            Main.stage.setScene(scene);
            Main.stage.setTitle("REGISTRO PEDIDOS");
            Main.stage.show();
        }catch(Exception e){
            System.err.println(e);
        }
    }
 @FXML
    private void registroProveedores(ActionEvent a){
        try{
           
            Parent root = FXMLLoader.load(getClass().getResource("Proveedores.fxml"));
            Main.stage.close(); 
            Scene scene = new Scene(root);	 
            Main.stage.setScene(scene);
            Main.stage.setTitle("REGISTRO PEDIDOS");
            Main.stage.show();
        }catch(Exception e){
            Alert mensaje = new Alert(Alert.AlertType.ERROR);
            mensaje.setContentText("No se puede ver proveedores ya que no  se cargo la base datos");
        }
    }
    @FXML
    private void registroPaises(ActionEvent a){
        try{
            Main.stage.close();
            Parent root = FXMLLoader.load(getClass().getResource("RegistroPaises.fxml"));
            Scene scene = new Scene(root);	 
            Main.stage.setScene(scene);
            Main.stage.setTitle("REGISTRO PEDIDOS");
            Main.stage.show();
        }catch(Exception e){
            System.err.println(e);
        }
    }
    @FXML
    private void cerrarSesion(ActionEvent a){
        try{
            
                Main.stage.close();
                Parent root = FXMLLoader.load(getClass().getResource("Inicio.fxml"));
                Scene scene = new Scene(root);
                    //scene.getStylesheets().add(getClass().getResource("/pkgEstilo/principal.css").toExternalForm());
	 
                Main.stage.setScene(scene);
                Main.stage.setTitle("INICIO");
                Main.stage.show();
            
        }catch(Exception e){
            System.err.println(e);
        }
    }
    @FXML
    private void buscarPedido(){
       try{
            
                Main.stage.close();
                Parent root = FXMLLoader.load(getClass().getResource("BusquedaPedidos.fxml"));
                Scene scene = new Scene(root);
                    //scene.getStylesheets().add(getClass().getResource("/pkgEstilo/principal.css").toExternalForm());
	 
                Main.stage.setScene(scene);
                Main.stage.setTitle("BUSQUEDA PEDIDOS");
                Main.stage.show();
            
        }catch(Exception e){
            System.err.println(e);
        } 
    }
}