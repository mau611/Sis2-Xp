/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static java.lang.Integer.parseInt;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author Cristian Choque
 */
public class validacionesBusquedas {
    Calendar fecha = new GregorianCalendar();
    
    public boolean validarNombre(String texto){
        int contador=0;
        boolean bandera=false;
        for(int i=0;i<texto.length();i++){
         if(letras(texto.charAt(i))==true){
          contador++;
         }
        }
        if(contador==texto.length()){
            bandera=true;
        }else{
            bandera=false;
        }
        return bandera;
    }
    public boolean validarTextoyNumeros(String texto){
        int contador=0;
        boolean bandera=false;
        for(int i=0;i<texto.length();i++){
         if(letrasyNumeros(texto.charAt(i))==true){
          contador++;
         }
        }
        if(contador==texto.length()){
            bandera=true;
        }else{
            bandera=false;
        }
        return bandera;
    }
    private boolean letras(char caracter){
        boolean bandera=false;
        if(' '==caracter || ' '==caracter){bandera=true;}
        if('a'==caracter || 'A'==caracter){bandera=true;}
        if('b'==caracter || 'B'==caracter){bandera=true;}
        if('c'==caracter || 'C'==caracter){bandera=true;}
        if('d'==caracter || 'D'==caracter){bandera=true;}
        if('e'==caracter || 'E'==caracter){bandera=true;}
        if('f'==caracter || 'F'==caracter){bandera=true;}
        if('g'==caracter || 'G'==caracter){bandera=true;}
        if('h'==caracter || 'H'==caracter){bandera=true;}
        if('i'==caracter || 'I'==caracter){bandera=true;}
        if('j'==caracter || 'J'==caracter){bandera=true;}
        if('k'==caracter || 'K'==caracter){bandera=true;}
        if('l'==caracter || 'L'==caracter){bandera=true;}
        if('m'==caracter || 'M'==caracter){bandera=true;}
        if('n'==caracter || 'N'==caracter){bandera=true;}
        if('o'==caracter || 'O'==caracter){bandera=true;}
        if('p'==caracter || 'P'==caracter){bandera=true;}
        if('q'==caracter || 'Q'==caracter){bandera=true;}
        if('r'==caracter || 'R'==caracter){bandera=true;}
        if('s'==caracter || 'S'==caracter){bandera=true;}
        if('t'==caracter || 'T'==caracter){bandera=true;}
        if('u'==caracter || 'U'==caracter){bandera=true;}
        if('v'==caracter || 'V'==caracter){bandera=true;}
        if('w'==caracter || 'W'==caracter){bandera=true;}
        if('x'==caracter || 'X'==caracter){bandera=true;}
        if('y'==caracter || 'Y'==caracter){bandera=true;}
        if('z'==caracter || 'Z'==caracter){bandera=true;}
        return bandera;
    }
       private boolean numeros(char caracter){
        boolean bandera=false;
        if('0'==caracter){bandera=true;}
        if('1'==caracter){bandera=true;}
        if('2'==caracter){bandera=true;}
        if('3'==caracter){bandera=true;}
        if('4'==caracter){bandera=true;}
        if('5'==caracter){bandera=true;}
        if('6'==caracter){bandera=true;}
        if('7'==caracter){bandera=true;}
        if('8'==caracter){bandera=true;}
        if('9'==caracter){bandera=true;}
        return bandera;
    }
    public boolean validarTelyCi(String texto){
        int contador=0;
        boolean bandera=false;
        for(int i=0;i<texto.length();i++){
         if(numeros(texto.charAt(i))==true){
          contador++;
         }
        }
        if(contador==texto.length()){
            bandera=true;
        }else{
            bandera=false;
        }
        return bandera;
    }
     private boolean letrasyNumeros(char caracter){
        boolean bandera=false;
        if(' '==caracter || ' '==caracter){bandera=true;}
        if('a'==caracter || 'A'==caracter){bandera=true;}
        if('b'==caracter || 'B'==caracter){bandera=true;}
        if('c'==caracter || 'C'==caracter){bandera=true;}
        if('d'==caracter || 'D'==caracter){bandera=true;}
        if('e'==caracter || 'E'==caracter){bandera=true;}
        if('f'==caracter || 'F'==caracter){bandera=true;}
        if('g'==caracter || 'G'==caracter){bandera=true;}
        if('h'==caracter || 'H'==caracter){bandera=true;}
        if('i'==caracter || 'I'==caracter){bandera=true;}
        if('j'==caracter || 'J'==caracter){bandera=true;}
        if('k'==caracter || 'K'==caracter){bandera=true;}
        if('l'==caracter || 'L'==caracter){bandera=true;}
        if('m'==caracter || 'M'==caracter){bandera=true;}
        if('n'==caracter || 'N'==caracter){bandera=true;}
        if('o'==caracter || 'O'==caracter){bandera=true;}
        if('p'==caracter || 'P'==caracter){bandera=true;}
        if('q'==caracter || 'Q'==caracter){bandera=true;}
        if('r'==caracter || 'R'==caracter){bandera=true;}
        if('s'==caracter || 'S'==caracter){bandera=true;}
        if('t'==caracter || 'T'==caracter){bandera=true;}
        if('u'==caracter || 'U'==caracter){bandera=true;}
        if('v'==caracter || 'V'==caracter){bandera=true;}
        if('w'==caracter || 'W'==caracter){bandera=true;}
        if('x'==caracter || 'X'==caracter){bandera=true;}
        if('y'==caracter || 'Y'==caracter){bandera=true;}
        if('z'==caracter || 'Z'==caracter){bandera=true;}
        if('0'==caracter){bandera=true;}
        if('1'==caracter){bandera=true;}
        if('2'==caracter){bandera=true;}
        if('3'==caracter){bandera=true;}
        if('4'==caracter){bandera=true;}
        if('5'==caracter){bandera=true;}
        if('6'==caracter){bandera=true;}
        if('7'==caracter){bandera=true;}
        if('8'==caracter){bandera=true;}
        if('9'==caracter){bandera=true;}
        return bandera;
     }
    public boolean fechaValida(String fechaInicial, String fechaFinal){
        String fechaInicio=fechaInicial;
        String fechaFin=fechaFinal;
        int anioInicial=parseInt(fechaInicio.substring(0, 4));
        int mesInicial=parseInt(fechaInicio.substring(5, 7));
        int diaInicial=parseInt(fechaInicio.substring(8, 10));
        int anioFinal=parseInt(fechaFin.substring(0, 4));
        int mesFinal=parseInt(fechaFin.substring(5, 7));
        int diaFinal=parseInt(fechaFin.substring(8, 10));
        boolean bandera=false;
        boolean banderaAnio=false;
        boolean banderaMes=false;
        boolean banderaDia=false;
        
        if(anioFinal>=anioInicial){
            banderaAnio=true;
        }
        if(mesFinal>=mesInicial){
            banderaMes=true;
        }
        if((mesInicial==mesFinal) && diaInicial>0 &&(diaFinal>diaInicial)){
            banderaDia=true;
            
        }else if(mesFinal>mesInicial && diaFinal>=diaInicial){
            banderaDia=true;
        }else{
            banderaDia=false;
        }
        if(banderaAnio==true&&banderaMes==true&&banderaDia==true){bandera =true;}
        else{bandera=false;}
        //System.out.println(diaInicial+"----"+diaFinal+"--"+mesInicial+"--"+mesFinal+"--"+resB);
        return bandera; 
        
    }
    public String cortar(String palabra){
    String texto=palabra;
    int cortado=parseInt(palabra.substring(0, 4));
    int mes=parseInt(palabra.substring(5, 7));
    int dia=parseInt(palabra.substring(8, 10));
    String res=cortado+":"+mes+":"+dia;
    return res;
    }
    /*
    private int listaMeses(int mes){
    int enero=31;
    int febrero=29;
    int marzo=31;
    int abril=30;
    int mayo=31;
    int junio=30;
    int julio=31;
    int agosto=31;
    int septiembre=30;
    int octubre=31;
    int noviembre=30;
    int diciembre=31;
    int res=0;
    if(mes==1){
        res=enero;
    }
    if(mes==2){
        res=febrero;
    }
    if(mes==3){
        res=marzo;
    }
    if(mes==4){
        res=abril;
    }
    if(mes==5){
        res=mayo;
    }
    if(mes==6){
        res=junio;
    }
    if(mes==7){
        res=julio;
    }
    if(mes==8){
        res=agosto;
    }
    if(mes==9){
        res=septiembre;
    }
    if(mes==10){
        res=octubre;
    }
    if(mes==11){
        res=noviembre;
    }
    if(mes==12){
        res=diciembre;
    }    
    return res;
    }*/
}
