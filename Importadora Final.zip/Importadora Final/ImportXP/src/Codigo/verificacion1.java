package Codigo;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class verificacion1

{
    Calendar fecha = new GregorianCalendar();
    public boolean validarPasword(String texto){
        boolean resultado = texto.matches("[-\\w\\.]+") ;
        resultado = resultado && (texto.length()>7);
        return resultado;
    }
    public boolean validarNombre(String texto){
       boolean resultado = texto.matches("[a-z]*") || texto.matches("[A-Z]*");
       resultado = resultado && (texto.length() > 3);
       return resultado;
    }
    public boolean validarCI(String texto){
        boolean resultado=true;
        try{
            Integer.parseInt(texto);
        }catch(Exception e){
            resultado = false;
        }
        resultado = resultado && (texto.length() > 4);
        return resultado;
    }
    public boolean validarTelf(String texto){
        boolean resultado=true;
        try{
            Integer.parseInt(texto);
        }catch(Exception e){
            resultado = false;
        }
        resultado = resultado && (texto.length() == 8 || texto.length() == 7);
        return resultado;
    }
    
    public String fechaGuardar(){
        String año=Integer.toString(fecha.get(Calendar.YEAR));
        String mes=Integer.toString( fecha.get(Calendar.MONTH)+1);
        String dia=Integer.toString(fecha.get(Calendar.DAY_OF_MONTH));
        String fecha;
        if(mes.length()==1&&dia.length()==1){
            fecha=0+dia+"-"+0+mes+"-"+año;
        }else{
            if(mes.length()==1){
                fecha=año+"-"+0+mes+"-"+dia;
            }else{
                if(dia.length()==1){
                    fecha=año+"-"+mes+"-"+0+dia;
                }else{
                    fecha=año+"-"+mes+"-"+dia;
                }
            }
        }
        return fecha;
    }
    public String fechaMostrar(){
         String año=Integer.toString(fecha.get(Calendar.YEAR));
         String mes=Integer.toString( fecha.get(Calendar.MONTH)+1);
         String dia=Integer.toString(fecha.get(Calendar.DAY_OF_MONTH));
         String fecha;
        if(mes.length()==1&&dia.length()==1){
            fecha=0+dia+"/"+0+mes+"/"+año;
        }else{
            if(mes.length()==1){
                fecha=dia+"/"+0+mes+"/"+año;
            }else{
                if(dia.length()==1){
                 fecha=0+dia+"/"+mes+"/"+año;
                }else{
                 fecha=dia+"/"+mes+"/"+año;
                }
            }
        }
        return fecha;
    }
        
}